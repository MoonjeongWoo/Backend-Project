exports.getCompany = (req, res) => {
  res.render("company");
};